# Moodle_LSM-2.0
https://github.com/Shabadoo89/Moodle_LSM-2.0

The program runs on the Xampp hosting services. This allows the computer to run it's own localhost server to display the website.

Please visit https://www.apachefriends.org/index.html to download the Xampp application.

Once installed, delete everything in the htdocs folder on the root of the Xampp folder. This is where all the files that are submitted in the GitHub repository should go.

next create a new database called users using the phpmyadmin web interface provided with xampp.

An exported table with the administrator and test account has been provided as well so just import that into the database using the import function within phpmyadmin webservice.

create a local server with all rights given named travis.

the website is now ready to work.